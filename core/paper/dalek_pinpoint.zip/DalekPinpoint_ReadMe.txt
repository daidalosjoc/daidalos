
=== DALEK PINPOINT ===
=== DALEK PINPOINT ITALIC ===
=== DALEK PINPOINT BOLD ===
=== DALEK PINPOINT BOLD ITALIC ===


Keith Bates / K-Type © 2018 (version 1.0)
www.k-type.com    -    info@k-type.com

DALEK PINPOINT is a clean and precise version of K-Type’s distressed DALEK typeface, a small caps face with overtones of Greek, Phoenician and Runic alphabets, based on Dalek comic book lettering from the 1960s.

The typeface includes Regular and Bold weights, plus an Italic and a Bold Italic which are optically corrected obliques. Each font contains a full complement of Latin Extended-A characters.

------------------------------------------------

== Licence Information ==

Licence URL: http://www.k-type.com/licences

------------------------------------------------

== Installing Fonts ==

Fonts are placed in your operating system's Fonts folder and will be made available to all the applications or programs you use.

= Windows =
Put the .ttf or .otf font file into C:\Windows\Fonts, or right-click on the font files > Install

= Mac =
Put the .ttf or .otf font file into /Library/Fonts

------------------------------------------------ 